<html>
    <title>K. Naveen Kumar PHP</title>
    <h1>K. Naveen Kumar PHP</h1>
<?php
// Your code here!
 echo "The SHA256 hash of \"K. Naveen Kumar\" is ".hash('sha256', 'K Naveen Kumar');
 
?>

<p>ASCII ART:</p>
<pre>
    ****       ****
     ** **      **
     **  **     **
     **   **    **
     **    **   **
     **     **  **
     **      ** **
    ****       ***
</pre>
<a href="fail.php">Click here to open fail.php</a><br>
<a href="check.php">Click here to open check.php</a>

</html>
