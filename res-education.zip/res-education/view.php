<?php
require_once "pdo.php";
require_once "util.php";

session_start();

if ( isset($_POST['done']) ) {
    header('Location: index.php');
    return;
}

$stmt = $pdo->query("SELECT * FROM Profile");
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);


?>
<html>
<title>K Naveen Kumar's Profile Information</title>
<head>
<?php
require_once "head.php";
 ?>
</head>

<body class="format">
<div class ="container">
<?php

echo "<h1>Profile Information";
echo "</h1>\n";


flashMessages();
$positions = loadPos($pdo, $_REQUEST['profile_id']);
$educations = loadEdu($pdo, $_REQUEST['profile_id']);
?>

<ul>
<?php
$stmt = $pdo->prepare("SELECT * FROM Profile WHERE profile_id = :pid");
$stmt->execute(array(
  ':pid' => $_GET['profile_id'])
);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
echo ("<p>");
echo ("First Name:");
echo(htmlentities($row['first_name']));
echo ("</p>");
echo ("<p>");
echo ("Last Name:");
echo(htmlentities($row['last_name']));
echo ("</p>");
echo ("<p>");
echo ("Email:");
echo(htmlentities($row['email']));
echo ("</p>");
echo ("<p>");
echo ("Headline:<br>");
echo(htmlentities($row['headline']));
echo ("</p>");
echo ("<p>");
echo ("Summary:<br>");
echo(htmlentities($row['summary']));
echo ("</p>");

echo ("</p>");
echo ("Education");
echo ("<ul style='list-style-type:disc'>");
foreach ($educations as $education) {
  echo('<li>');
  echo($education['year'].':'.$education['name']);
  echo('</li>');
}
echo('</ul>');
echo ("</p>");

echo ("</p>");
echo ("Position");
echo ("<ul style='list-style-type:disc'>");
foreach ($positions as $position) {
  echo('<li>');
  echo($position['year'].':'.$position['description']);
  echo('</li>');
}
echo('</ul>');
echo ("</p>");


?>

<form method="POST">
<input type="submit" name="done" value="Done">
</form>
</div>
</body>
</html>
