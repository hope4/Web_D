<?php
require_once "pdo.php";
session_start();
// Demand a GET parameter
if ( ! isset($_SESSION['name']) ){
    die('Not logged in');
}

// If the user requested logout go back to index.php
if ( isset($_POST['cancel']) ) {
    header('Location: view.php');
    return;
}

if(isset($_POST['Add']) && isset($_POST['year']) && isset($_POST['mileage'])){

  if(is_numeric($_POST['year']) && is_numeric($_POST['mileage'])){
    
      if(strlen($_POST['make']) > 1 ){
         $stmt = $pdo->prepare('INSERT INTO autos
        (make, year, mileage) VALUES ( :mk, :yr, :mi)');
         $stmt->execute(array(
        ':mk' => $_POST['make'],
        ':yr' => $_POST['year'],
        ':mi' => $_POST['mileage'])
        );
        $_SESSION['success'] = "Record inserted";
        header("Location: view.php");
        return;
	}
      else{
     $_SESSION['failure'] = "Make is required";
        header("Location: add.php");
        return;
	
      }
  }
  else{
   $_SESSION['failure'] = "Mileage and year must be numeric";
   header("Location: add.php");
   return;
  }
}
?>
<html>
<title>K Naveen Kumar's Automobile Tracker</title>
<head>
<style>
.format{
  position:fixed;
  top: 7%;
  left: 13%;
}
</style>
</head><body class="format"><table border="1">
<?php
if ( isset($_SESSION['name']) ) {
    echo "<h1>Tracking Autos for ";
    echo htmlentities($_SESSION['name']);
    echo "</h1>\n";
}

if ( isset($_SESSION['failure']) ) {
    echo('<p style="color: red;">'.htmlentities($_SESSION['failure'])."</p>\n");
    unset($_SESSION['failure']);
}

if ( isset($_SESSION['success']) ) {
    echo('<p style="color: green;">'.htmlentities($_SESSION['success'])."</p>\n");
    unset($_SESSION['success']);
}

?>
</table>
<form method="POST">
<p>Make:
<input type="text" name="make" size="40"></p>
<p>Year:
<input type="text" name="year"></p>
<p>Mileage:
<input type="text" name="mileage"></p>
<input type="submit" name="Add" value="Add"> 
<input type="submit" name="cancel" value="Cancel"></form>

<!--<h2>Automobiles</h2>

<ul>
<?php
foreach ( $rows as $row ) {
   echo '<li>'.htmlentities($row['year']).' '.htmlentities($row['make']).' / '.htmlentities($row['mileage']).'</li>';
}
?> 
</ul>-->
</body>
</html>


