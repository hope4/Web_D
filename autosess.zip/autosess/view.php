<?php
require_once "pdo.php";
session_start();
// Demand a GET parameter
if ( ! isset($_SESSION['name'])) {
    die('Not logged in');
}

// If the user requested logout go back to index.php
/*if ( isset($_POST['logout']) ) {
    session_start();
    session_destroy();
    header('Location: index.php');
    return;
}

if ( isset($_POST['Addnew']) ) {
    header('Location: add.php');
    return;
}

/*$failure = false;
$success = false;
if(isset($_POST['Add']) && isset($_POST['year']) && isset($_POST['mileage'])){

  if(is_numeric($_POST['year']) && is_numeric($_POST['mileage'])){
    
      if(strlen($_POST['make']) > 1 ){
         $stmt = $pdo->prepare('INSERT INTO autos
        (make, year, mileage) VALUES ( :mk, :yr, :mi)');
         $stmt->execute(array(
        ':mk' => $_POST['make'],
        ':yr' => $_POST['year'],
        ':mi' => $_POST['mileage'])
        );
        $success = "Record inserted";
	}
      else{
     $failure = "Make is required";

      }
  }
  else{
   $failure = "Mileage and year must be numeric";
  }
}
*/

$stmt = $pdo->query("SELECT make, year, mileage FROM autos");
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<html>
<title>K Naveen Kumar's Automobile Tracker</title>
<head>
<style>
.format{
  position:fixed;
  top: 7%;
  left: 13%;
}
</style>
</head><body class="format"><table border="1">
<?php
if ( isset($_SESSION['name']) ) {
    echo "<h1>Tracking Autos for ";
    echo htmlentities($_SESSION['name']);
    echo "</h1>\n";
}

/*if ( $failure !== false ) {
    // Look closely at the use of single and double quotes
    echo('<p style="color: red;">'.htmlentities($failure)."</p>\n");
}*/

if ( isset($_SESSION['success']) ) {
    echo('<p style="color: green;">'.htmlentities($_SESSION['success'])."</p>\n");
    unset($_SESSION['success']);
}

?>
<!--</table>
<form method="POST">
<p>Make:
<input type="text" name="make" size="40"></p>
<p>Year:
<input type="text" name="year"></p>
<p>Mileage:
<input type="text" name="mileage"></p>
<input type="submit" name="Addnew" value="Add New"> |
<a href="logout.php"><input type="submit" name="logout" value="Logout"></a></form>-->

<h2>Automobiles</h2>

<ul>
<?php
foreach ( $rows as $row ) {
   echo '<li>'.htmlentities($row['year']).' '.htmlentities($row['make']).' / '.htmlentities($row['mileage']).'</li>';
}
?> 
</ul>

<a href="add.php">Add New</a> |
<a href="logout.php">Logout</a>
</body>
</html>


