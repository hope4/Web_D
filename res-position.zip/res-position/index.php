<?php
require_once "pdo.php";
require_once "util.php";

session_start();
?>
<html>
<head>
<title>K Naveen Kumar's Index Page</title>
<?php require_once "bootstrap.php"; ?>
</head>
<body>
<div class="container">
<h1>K Naveen Kumar's Resume Registry</h1>
<p>

<?php
if (isset($_SESSION['name'])) {
flashMessages();
echo('<table border="1">'."\n");
$stmt = $pdo->query("SELECT * FROM Profile");
echo ('<a href="logout.php">Logout</a><br><br>');
if($stmt->rowCount() > 0){
  echo "<tr><th>";
  echo("Name");
  echo("</th><th>");
  echo("Headline");
  echo("</th><th>");
  echo("Action");
  echo("</th><tr>");
while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {
  echo "<tr><td>";
  echo('<a href="view.php?profile_id='.$row['profile_id'].'">'.htmlentities($row['first_name']) . htmlentities($row['last_name']).'</a>');
  echo("</td><td>");
  echo(htmlentities($row['headline']));
  echo("</td><td>");
  echo('<a href="edit.php?profile_id='.$row['profile_id'].'">Edit</a>  ');
  echo('<a href="delete.php?profile_id='.$row['profile_id'].'">Delete</a>');
  echo("</td></tr>\n");
}
echo ('</table>'."\n");
}

echo ('<a href="add.php">Add New Entry</a><br><br>');
}

else{
echo('<div>');
echo('<p>');
echo('<a href= "login.php" >Please log in</a>');
echo('</p>');
echo('<p>');
echo('<table border="1">'."\n");
$stmt = $pdo->query("SELECT * FROM Profile");
if($stmt->rowCount() > 0){
  echo "<tr><th>";
  echo("Name");
  echo("</th><th>");
  echo("Headline");
  echo("</th><tr>");
while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {
    echo "<tr><td>";
    echo('<a href="view.php?profile_id='.$row['profile_id'].'">'.htmlentities($row['first_name']) . htmlentities($row['last_name']).'</a>');
    echo("</td><td>");
    echo(htmlentities($row['headline']));
    echo("</td><td>");
}
echo ('</table>'."\n");
echo('</p>');
echo('</div>');
}
}
?>
</body>


</html>
