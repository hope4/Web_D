<?php
require_once "pdo.php";
session_start();

if ( isset($_POST['cancel']) ) {
    header('Location: index.php');
    return;
}

if ( isset($_POST['delete']) && isset($_GET['profile_id']) ) {
    $sql = "DELETE FROM Profile WHERE profile_id = :zip";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array(':zip' => $_GET['profile_id']));
    $_SESSION['success'] = 'Profile deleted';
    header( 'Location: index.php' ) ;
    return;
}

// Guardian: Make sure that autos_id is present
if ( ! isset($_GET['profile_id']) ) {
  $_SESSION['failure'] = "";
  header('Location: index.php');
  return;
}

$stmt = $pdo->prepare("SELECT first_name, last_name FROM Profile where profile_id = :xyz");
$stmt->execute(array(":xyz" => $_GET['profile_id']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if ( $row === false ) {
    $_SESSION['failure'] = '';
    header( 'Location: index.php' ) ;
    return;
}
echo("<div>");
echo("<h1>");
echo("Deleting Profile");
echo ("</h1>");
echo ("<p>");
echo ("First Name:");
echo(htmlentities($row['first_name']));
echo ("</p>");
echo ("<p>");
echo ("Last Name:");
echo(htmlentities($row['last_name']));
echo ("</p>");
echo ("<p>");
?>

<p>Confirm: Deleting <?= htmlentities($row['first_name']).htmlentities($row['last_name']) ?></p>

<form method="post">
<input type="hidden" name="profile_id" value="<?= $row['profile_id'] ?>">
<input type="submit" value="Delete" name="delete">
<input type="submit" value="Cancel" name="cancel">
</form>
</div>
</body>
</html>
