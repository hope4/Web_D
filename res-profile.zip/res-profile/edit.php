<?php
require_once "pdo.php";
session_start();

if ( isset($_POST['cancel']) ) {
    header('Location: index.php');
    return;
}

if (isset($_POST['save']) && isset($_POST['first_name']) && isset($_POST['last_name'])
     && isset($_POST['email']) && isset($_POST['headline'])  && isset($_POST['summary'])) {

    // Data validation
    if(strlen($_POST['first_name']) < 1 || strlen($_POST['last_name']) < 1 || strlen($_POST['email']) < 1 || strlen($_POST['headline']) < 1 || strlen($_POST['summary']) < 1){
     $_SESSION['failure'] = "All values are required";
        header("Location: edit.php?profile_id=".$_POST['profile_id']);
        return;
    }
    else if(strpos($_POST['email'],'@')==false){
      $_SESSION['failure'] = "Email must have an at-sign (@)";
      header("Location: edit.php?profile_id=".$_POST['profile_id']);
      return;
    }

//:mk, :mo, :yr, :mi
    $sql = "UPDATE Profile SET first_name = :fname,last_name = :lname, email = :email, headline = :headline, summary =:summary
            WHERE profile_id = :profile_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array(
        ':fname' => $_POST['first_name'],
        ':lname' => $_POST['last_name'],
        ':email' => $_POST['email'],
        ':headline' => $_POST['headline'],
        ':summary' => $_POST['summary'],
        ':profile_id' => $_GET['profile_id']));
    $_SESSION['success'] = "Profile updated";
    header( 'Location: index.php' ) ;
    return;

}

// Guardian: Make sure that user_id is present
 if ( ! isset($_GET['profile_id']) ) {
   header('Location: index.php');
   return;
 }

$stmt = $pdo->prepare("SELECT * FROM Profile where profile_id = :xyz");
$stmt->execute(array(":xyz" => $_GET['profile_id']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if ( $row === false ) {
    $_SESSION['error'] = 'Bad value for profile_id';
    header( 'Location: index.php') ;
    return;
}

// Flash pattern
if ( isset($_SESSION['failure']) ) {
    echo '<p style="color:red">'.$_SESSION['failure']."</p>\n";
    unset($_SESSION['failure']);
}
if ( isset($_SESSION['name']) ) {
    echo '<div class="container">';
    echo "<h1>Editing Profile for ";
    echo htmlentities($_SESSION['name']);
    echo "</h1>\n";
    echo "</div>";
}

$fname = htmlentities($row['first_name']);
$lname = htmlentities($row['last_name']);
$email = htmlentities($row['email']);
$headline = htmlentities($row['headline']);
$summary = htmlentities($row['summary']);
$profileid= $row['profile_id'];
?>
<form method="post">
<p>First Name:
<input type="text" name="first_name" value="<?= $fname ?>"></p>
<p>Last Name:
<input type="text" name="last_name" value="<?= $lname ?>"></p>
<p>Email:
<input type="text" name="email" value="<?= $email ?>"></p>
<p>Headline:<br>
<input type="text" name="headline" value="<?= $headline ?>"></p>
<p>Summary:<br>
<textarea name="summary" rows="8" cols="80" ><?= $summary ?></textarea>
</p>

<input type="hidden" name="profile_id" value="<?= $profileid ?>">
<p><input type="submit" name="save" value="Save"/>
<input type="submit" name="cancel" value="Cancel"></p>
</form>
