<?php
require_once "pdo.php";
session_start();

if ( isset($_POST['done']) ) {
    header('Location: index.php');
    return;
}

$stmt = $pdo->query("SELECT * FROM Profile");
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<html>
<title>K Naveen Kumar's Profile Information</title>
<head>
<style>
.format{
  position:fixed;
  top: 7%;
  left: 13%;
}
</style>
</head><body class="format"><table border="1">
<?php

echo "<h1>Profile Information";
echo "</h1>\n";


/*if ( $failure !== false ) {
    // Look closely at the use of single and double quotes
    echo('<p style="color: red;">'.htmlentities($failure)."</p>\n");
}*/

if ( isset($_SESSION['success']) ) {
    echo('<p style="color: green;">'.htmlentities($_SESSION['success'])."</p>\n");
    unset($_SESSION['success']);
}

?>
<!--</table>
<form method="POST">
<p>Make:
<input type="text" name="make" size="40"></p>
<p>Year:
<input type="text" name="year"></p>
<p>Mileage:
<input type="text" name="mileage"></p>
<input type="submit" name="Addnew" value="Add New"> |
<a href="logout.php"><input type="submit" name="logout" value="Logout"></a></form>-->


<ul>
<?php
$stmt = $pdo->prepare("SELECT * FROM Profile WHERE profile_id = :pid");
$stmt->execute(array(
  ':pid' => $_GET['profile_id'])
);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
echo("<div>");
echo ("<p>");
echo ("First Name:");
echo(htmlentities($row['first_name']));
echo ("</p>");
echo ("<p>");
echo ("Last Name:");
echo(htmlentities($row['last_name']));
echo ("</p>");
echo ("<p>");
echo ("Email:");
echo(htmlentities($row['email']));
echo ("</p>");
echo ("<p>");
echo ("Headline:<br>");
echo(htmlentities($row['headline']));
echo ("</p>");
echo ("<p>");
echo ("Summary:<br>");
echo(htmlentities($row['summary']));
echo ("</p>");
?>

<form method="POST">
<input type="submit" name="done" value="Done">
</form>
</div>
</body>
</html>
