<?php
require_once "pdo.php";
session_start();
?>
<html>
<head>
<title>K Naveen Kumar's Index Page</title>
<?php require_once "bootstrap.php"; ?>
</head>
<body>
<div class="container">
<h1>Welcome to Automobiles Database</h1>
<p>

<?php
if (isset($_SESSION['name'])) {
if ( isset($_SESSION['failure']) ) {
    echo '<p style="color:red">'.$_SESSION['error']."</p>\n";
    unset($_SESSION['error']);
}
if ( isset($_SESSION['success']) ) {
    echo '<p style="color:green">'.$_SESSION['success']."</p>\n";
    unset($_SESSION['success']);
}
echo('<table border="1">'."\n");
$stmt = $pdo->query("SELECT * FROM automobiles");
if($stmt->rowCount() > 0){
while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {
    echo "<tr><td>";
    echo(htmlentities($row['make']));
    echo("</td><td>");
    echo(htmlentities($row['model']));
    echo("</td><td>");
    echo(htmlentities($row['year']));
    echo("</td><td>");
    echo(htmlentities($row['mileage']));
    echo("</td><td>");
    echo('<a href="edit.php?autos_id='.$row['autos_id'].'">Edit</a> / ');
    echo('<a href="delete.php?autos_id='.$row['autos_id'].'">Delete</a>');
    echo("</td></tr>\n");
}
echo ('</table>'."\n");
}
else{
echo('No rows found');
}
echo ('<br><br><a href="add.php">Add New Entry</a><br><br>');
echo ('<a href="logout.php">Logout</a>');
}

else{
echo('<a href= "login.php" >Please log in</a>');
echo('</p>');
echo('<p>');
echo('<a href="add.php">add data</a>');
echo('</p>');
echo('</div>');
}
?>
</body>


</html>
