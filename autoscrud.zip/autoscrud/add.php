<?php
require_once "pdo.php";
session_start();
// Demand a GET parameter
if ( ! isset($_SESSION['name']) ){
    die('ACCESS DENIED');
}

// If the user requested logout go back to index.php
if ( isset($_POST['cancel']) ) {
    header('Location: index.php');
    return;
}

if(isset($_POST['Add']) && isset($_POST['make']) && isset($_POST['model']) && isset($_POST['year']) && isset($_POST['mileage'])){

if(strlen($_POST['make']) > 1 && strlen($_POST['model']) > 1 && strlen($_POST['year']) > 1 && strlen($_POST['mileage']) > 1){
  if(is_numeric($_POST['year']) && is_numeric($_POST['mileage'])){
    
      
         $stmt = $pdo->prepare('INSERT INTO automobiles
        (make,model, year, mileage) VALUES ( :mk, :mo, :yr, :mi)');
         $stmt->execute(array(
        ':mk' => $_POST['make'],
        ':mo' => $_POST['model'],
        ':yr' => $_POST['year'],
        ':mi' => $_POST['mileage'])
        );
        $_SESSION['success'] = "Record added";
        header("Location: index.php");
        return;
	}
	 else{
   $_SESSION['failure'] = "Mileage and year must be numeric";
   header("Location: add.php");
   return;
     
      }
  }
 else{
     $_SESSION['failure'] = "All values are required";
        header("Location: add.php");
        return;
	
 
  }
}
?>
<html>
<title>K Naveen Kumar's Automobile Tracker</title>
<head>
<style>
.format{
  position:fixed;
  top: 7%;
  left: 13%;
}
</style>
</head><body class="format"><table border="1">
<?php
if ( isset($_SESSION['name']) ) {
    echo "<h1>Tracking Automobiles for ";
    echo htmlentities($_SESSION['name']);
    echo "</h1>\n";
}

if ( isset($_SESSION['failure']) ) {
    echo('<p style="color: red;">'.htmlentities($_SESSION['failure'])."</p>\n");
    unset($_SESSION['failure']);
}

if ( isset($_SESSION['success']) ) {
    echo('<p style="color: green;">'.htmlentities($_SESSION['success'])."</p>\n");
    unset($_SESSION['success']);
}

?>
</table>
<form method="POST">
<p>Make:
<input type="text" name="make" size="40"></p>
<p>Model:
<input type="text" name="model" size="40"></p>
<p>Year:
<input type="text" name="year"></p>
<p>Mileage:
<input type="text" name="mileage"></p>
<input type="submit" name="Add" value="Add"> 
<input type="submit" name="cancel" value="Cancel"></form>

<!--<h2>Automobiles</h2>

<ul>
<?php
foreach ( $rows as $row ) {
   echo '<li>'.htmlentities($row['year']).' '.htmlentities($row['make']).' / '.htmlentities($row['mileage']).'</li>';
}
?> 
</ul>-->
</body>
</html>


