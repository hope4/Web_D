<!DOCTYPE html>
<html>
<head>
<title>K Naveen Kumar - Rock Paper Scissors</title>
<?php require_once "bootstrap.php"; ?>
</head>
<body>
<div class="container">
<h1>Welcome to Rock Paper Scissors</h1>
<p>
<a href="login.php">Please Log In</a>
</p>
<p>
<a href="game.php">game.php</a>
</div>
</body>

