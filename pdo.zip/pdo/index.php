<!DOCTYPE html>
<html>
<head>
<title>K Naveen Kumar - Autos Database</title>
<?php require_once "bootstrap.php"; ?>
</head>
<body>
<div class="container">
<h1>Welcome to Autos Database</h1>
<p>
<a href="login.php">Please Log In</a>
</p>
<p>
<a href="autos.php">autos.php</a>
</div>
</body>

